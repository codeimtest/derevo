$('.menu-btn').click(function(){
    $('header ul').toggleClass('active')
})